define(
"dojox/grid/enhanced/nls/ar/EnhancedGrid", ({
	singleSort: "فرز منفرد",
	nestedSort: "فرز متداخل",
	ascending: "اضغط للفرز تصاعديا",
	descending: "اضغط للفرز تنازليا ",
	sortingState: "${0} - ${1}",
	unsorted: "لا تقم بفرز هذا العمود",
	indirectSelectionRadio: "الصف ${0}، اختيار منفرد، اختيار دائري",
	indirectSelectionCheckBox: "الصف ${0}، اختيارات متعددة، مربع اختيار",
	selectAll: "تحديد كل"
})
);
